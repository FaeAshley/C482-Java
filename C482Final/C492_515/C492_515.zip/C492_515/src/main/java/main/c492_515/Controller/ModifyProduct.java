package main.c492_515.Controller;


import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import main.c492_515.Main;
import main.c492_515.Model.*;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static main.c492_515.Model.Inventory.lookupPart;

public class ModifyProduct implements Initializable {

    public TableView ProductPart1;
    public TableColumn ProductPart1Id;
    public TableColumn ProductPart1Name;
    public TableColumn ProductPart1Inventory;
    public TableColumn ProductPart1Price;
    public TableView ProductPart2;
    public TableColumn ProductPart2Id;
    public TableColumn ProductPart2Name;
    public TableColumn ProductPart2Inventory;
    public TableColumn ProductPart2Price;
    public TextField searchParts;
    public TextField name;
    public TextField stock;
    public TextField price;
    public TextField min;
    public TextField max;
    public Button save;
    public TextField id;
    static Product modifiedProduct;


    /** set Save Product method.
     * pulls static variable product over from the selected item of the Producs tableView on the previous screen
     * @param product - selected product from prior Main screen
     */
    public static void setSaveProduct (Product product){
        modifiedProduct = product;
        System.out.println(modifiedProduct);

    }

    /** initialize method
     * initializes and pulls data from setSaveProduct modifiedProduct product and populates fields on screen with the data.
     * Also sets tableView tables and columns
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        id.setText(String.valueOf(modifiedProduct.getId()));
        name.setText(modifiedProduct.getName());
        stock.setText(String.valueOf(modifiedProduct.getStock()));
        min.setText(String.valueOf(modifiedProduct.getMin()));
        max.setText(String.valueOf(modifiedProduct.getMax()));
        price.setText(String.valueOf(modifiedProduct.getPrice()));

        ProductPart1.setItems(Inventory.getAllParts());
        ProductPart1Id.setCellValueFactory(new PropertyValueFactory<>("id"));
        ProductPart1Name.setCellValueFactory(new PropertyValueFactory<>("name"));
        ProductPart1Inventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ProductPart1Price.setCellValueFactory(new PropertyValueFactory<>("price"));

        ProductPart2.setItems(modifiedProduct.getAssociatedParts());
        ProductPart2Id.setCellValueFactory(new PropertyValueFactory<>("id"));
        ProductPart2Name.setCellValueFactory(new PropertyValueFactory<>("name"));
        ProductPart2Inventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ProductPart2Price.setCellValueFactory(new PropertyValueFactory<>("price"));

    }

    /**
     * Loads up Main.fxml and exits AddProduct
     * @param actionEvent - triggered by button click
     * @throws Exception
     */
    public void toMain(ActionEvent actionEvent) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Main.fxml"));
        Stage stage = (Stage) ((Button)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load(), 900, 390);
        stage.setTitle("Inventory System");
        stage.setScene(scene);
        stage.show();
    }

    /** part search method.
     * Performs linear search through Observable List allParts using lookupPart method based on input information.
     * First attempts to search by string Name and if no match is found, search is performed by int ID
     * @param actionEvent - type in search box and push "enter" on keyboard
     */
    public void searchParts(ActionEvent actionEvent) {
        String q = searchParts.getText();
        ObservableList<Part> parts = lookupPart(q);
        ProductPart1.setItems(parts);
        searchParts.setText("");
    }

    /**
     * removes the selected part from the associatedParts list
     * @param actionEvent - triggered by button
     */
    public void removeAssociatedPart(ActionEvent actionEvent) {
        Part selectedPart = (Part) ProductPart2.getSelectionModel().getSelectedItem();
        modifiedProduct.deleteAssociatedPart(selectedPart);
    }

    /**
     * adds selected part from tableView to the product's associatedParts list, displays error if no part is selected
     * @param actionEvent - triggered by button click
     */
    public void addAssociatedPart(ActionEvent actionEvent) {
        Part selectedPart = (Part) ProductPart1.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            modifiedProduct.addAssociatedPart(selectedPart);
        }
        else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Please select a part");
            alert.showAndWait();
        }
        ProductPart2.setItems(modifiedProduct.getAssociatedParts());

    }

    /** is integer method.
     * method checks to see if input is integer or not. Returns true if integer, otherwise returns false
     * @param textField - evaluation input
     * @return return true for integer, false for all other values
     */
    public boolean isInteger(String textField) {
        try {
            Integer.parseInt(textField);
            return true;
        }
        catch(NumberFormatException e ) {
            return false;
        }
    }
    /** is double method.
     * method checks to see if input is double or not. Returns true if double, otherwise returns false
     * @param textField - evaluation input
     * @return return true for double, false for all other values
     */
    public boolean isDouble(String textField) {
        try {
            Double.parseDouble(textField);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    /** save modify Product method.
     * Method verifies all information put into text fields meets required criteria, displays error messages if not.
     * Once all information is correct, it updates the existing Product and updates the allProducts list and returns
     * the user to the main screen where the new information is displayed in the table.
     * @param actionEvent - triggered by clicking "save" button
     * @throws IOException
     */
    public void saveProduct(ActionEvent actionEvent) throws IOException {
        if (name.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR,
                    "Please enter part name");
            alert.showAndWait();
            return;
        }
        if (price.getText().isBlank() || !isDouble(price.getText()) || !isDouble(price.getText())) {
            Alert alert = new Alert(Alert.AlertType.ERROR,
                    "Please enter numeric value for price");
            alert.showAndWait();
            return;
        }
        if (stock.getText().isBlank() || !isInteger(stock.getText())) {
            Alert alert = new Alert(Alert.AlertType.ERROR,
                    "Please enter integer value for inventory amount");
            alert.showAndWait();
            return;
        }
        if (min.getText().isBlank() || !isInteger(min.getText())) {
            Alert alert = new Alert(Alert.AlertType.ERROR,
                    "Please enter integer value for minimum inventory amount");
            alert.showAndWait();
            return;
        }
        if (max.getText().isBlank() || !isInteger(max.getText())) {
            Alert alert = new Alert(Alert.AlertType.ERROR,
                    "Please enter integer value for max inventory");
            alert.showAndWait();
            return;
        }


        //check if fields meet integer criteria
        try {
            double priceD = Double.parseDouble(price.getText());
            int stockI = Integer.parseInt(stock.getText());
            int minI = Integer.parseInt(min.getText());
            int maxI = Integer.parseInt(max.getText());
            if (stockI < minI){
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        "Current inventory amount must be greater than or equal to minimum inventory");
                alert.showAndWait();
                return;
            }
            if (minI > maxI) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        " Minimum inventory amount must be greater than or equal to maximum inventory amount");
                alert.showAndWait();
                return;
            }
            if (stockI > maxI){
                Alert alert = new Alert(Alert.AlertType.INFORMATION,
                        "Current inventory amount must be less than or equal to maximum inventory");
                alert.showAndWait();
                return;
            }
        }
        catch (NumberFormatException e){
            return;
        }
        if (modifiedProduct.getAssociatedParts() == null){
            Alert alert = new Alert(Alert.AlertType.ERROR,
                    "Product must have at least one item in associatedParts list");
            alert.showAndWait();
            return;
        }

        modifiedProduct.setName(name.getText());
        modifiedProduct.setStock(Integer.parseInt(stock.getText()));
        modifiedProduct.setPrice(Double.parseDouble(price.getText()));
        modifiedProduct.setMin(Integer.parseInt(min.getText()));
        modifiedProduct.setMax(Integer.parseInt(max.getText()));

        Inventory.updateProduct(Inventory.getAllProducts().indexOf(modifiedProduct),
                modifiedProduct);

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Main.fxml"));
        Stage stage = (Stage) ((Button)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(fxmlLoader.load(), 900, 390);
        stage.setTitle("Inventory System");
        stage.setScene(scene);
        stage.show();

    }
}
